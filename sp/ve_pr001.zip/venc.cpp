#ifndef __vochant_encrypt
#define __vochant_encrypt

#include <string>
#include <cstdio>
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <windows.h>

HANDLE hOut;

void SetColor(int __fg=7,int __bg=0)
{
	SetConsoleTextAttribute(hOut,(__bg<<4)|__fg);
}

using namespace std;

string __BaseString="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
string __ValidString="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789`~!@#$%^&*()-=_+[]{}\\|;'\",./<>?";

#define __BaseLength 65
#define __ValidLength 93

bool __ValidCharTag[128],__bInit;
int __BaseToValid[128],__ValidToBase[128];

int __BaseToInt[256],__ValidToInt[256];

string __Mask;

fstream __OutputStream;

void __InitSystem()
{
	hOut=GetStdHandle(STD_OUTPUT_HANDLE);
	srand(time(0));
	for(int i=0;i<__BaseLength;i++)
	{
		__BaseToInt[(int)__BaseString[i]]=i;
	}
	for(int i=0;i<__ValidLength;i++)
	{
		__ValidToInt[(int)__ValidString[i]]=i;
	}
	__bInit=true;
}

void __GenerateMask()
{
	int __TargetChar,__FreeCounter;
	memset(__ValidCharTag,0,sizeof(__ValidCharTag));
	__Mask="";
	for(int i=0;i<__BaseLength;i++)
	{
		__TargetChar=rand()%(__ValidLength-i);
		__FreeCounter=0;
		for(int j=0;j<__ValidLength;j++)
		{
			if(__FreeCounter==__TargetChar&&!__ValidCharTag[j])
			{
				__BaseToValid[i]=j;
				__ValidToBase[j]=i;
				__ValidCharTag[j]=true;
				__Mask+=__ValidString[j];
				break;
			}
			if(!__ValidCharTag[j])
			{
				__FreeCounter++;
			}
		}
	}
}

void __InitFromMask()
{
	for(int i=0;i<__BaseLength;i++)
	{
		__BaseToValid[i]=__ValidToInt[(int)__Mask[i]];
		__ValidToBase[__ValidToInt[(int)__Mask[i]]]=i;
	}
}

int __EncoderReleaseBranch,__EncoderUpdate,__EncoderSubversion,__EncoderCompile;

struct __EncodeResult
{
	bool bSuccess;
	string strMessage;
};

struct __DecodeResult
{
	bool bSuccess;
	string strMessage;
};

string __GetFileCodec(string __FileName)
{
	string __Result="";
	int __Length=__FileName.length();
	for(int i=0;i<__Length;i++)
	{
		if(__FileName[i]=='.')
		{
			__Result="";
		}
		else
		{
			__Result+=__FileName[i];
		}
	}
	return __Result;
}

string __GetFileIndex(string __FileName)
{
	string __Result="",__Temp="";
	int __Length=__FileName.length();
	for(int i=0;i<__Length;i++)
	{
		if(__FileName[i]=='.')
		{
			__Result+=__Temp;
			__Temp="";
		}
		__Temp+=__FileName[i];
	}
	return __Result;
}

string __GetFileName(string __FileName)
{
	__FileName=__GetFileIndex(__FileName);
	string __Result="";
	int __Length=__FileName.length();
	for(int i=0;i<__Length;i++)
	{
		if(__FileName[i]=='\\')
		{
			__Result="";
		}
		else
		{
			__Result+=__FileName[i];
		}
	}
	return __Result;
}

namespace __Encoder
{
	__EncodeResult __prebuild(fstream &__OutputStream)
	{
		__EncodeResult __Result;
		if(!__bInit)
		{
			printf("***Program is not ready, preparing environment...***\n");
			__InitSystem();
			printf("***Successfully to init.***\n");
		}
		printf("*****Proccessing file public header...*****\n[1/2] Making the static header...\n");
		__OutputStream<<"Vencrypt?\n";
		printf("[2/2] Making the version header...\n");
		__OutputStream<<">Match-FileInfo\n:Change Generator-Display-Name\nVochant Encrypt CLI Tool Version 0.1 (Pre-Release)\n";
		printf("***Setup output file successfully.***\n");
		__Result.bSuccess=true;
		__Result.strMessage="Successfully wrote the public header of the target file.\n";
		return __Result;
	}

	__EncodeResult __endfile(fstream &__OutputStream)
	{
		__EncodeResult __Result;
		__OutputStream<<">End-Matches\n!return-value 0\n";
		__Result.bSuccess=true;
		__Result.strMessage="Successfully wrote the end of the target file.\n";
		return __Result;
	}

	__EncodeResult __pr_001(string __InputFileName,fstream &__OutputStream)
	{
		string __ShortName=__GetFileName(__InputFileName);
		__EncodeResult __Result;
		string __Command="certutil -f -encode \""+__InputFileName+"\" \""+__ShortName+".tmp\"";
		printf("*****Proccessing the file \"%s.%s\"...*****\n",__ShortName.c_str(),__GetFileCodec(__InputFileName).c_str());
		printf("***Converting to Base64...***\n");
		printf("***System: Windows, Method Type: Certificate Util***\n");
		system(__Command.c_str());
		__Command="del /f /s /q \""+__ShortName+".tmp\"";
		printf("***Convert is finished.***\n");
		printf("***Proccessing file private header...***\n[1/4] Making the static header...\n");
		fstream __InputStream;
		__InputStream.open(__ShortName+".tmp",ios::in);
		if(!__InputStream.good())
		{
			__Result.bSuccess=false;
			__Result.strMessage="File not found: \""+__ShortName+__GetFileCodec(__InputFileName)+"\"\n";
			return __Result;
		}
		__OutputStream<<">New-File\n";
		printf("[2/4] Making the fileinfo header...\n");
		__OutputStream<<"!filetype "<<__GetFileCodec(__InputFileName)<<"\n!filename "<<__ShortName<<"\n";
		printf("[3/4] Making the version header...\n");
		__OutputStream<<"!branch 0\n";
		__OutputStream<<"!version 0\n";
		printf("[4/4] Making the dynamic header...\n");
		__GenerateMask();
		printf("  <!> Mask generated.\n");
		__OutputStream<<__Mask<<endl;
		printf("  <!> Mask wrote.\n");
		printf("***Converting file...***\nOver 0 lines converted.");
		char __In[256]="Nothing";
		string __ConvIn="Nothing";
		string __Out;
		bool __bSetup=false;
		int __Length,__Proced=0;
		__InputStream.getline(__In,sizeof(__In));
		__ConvIn=__In;
		__Length=__ConvIn.length();
		while(__ConvIn!="-----END CERTIFICATE-----")
		{
			if(!__bSetup)
			{
				if(__ConvIn!="-----BEGIN CERTIFICATE-----")
				{
					__Result.bSuccess=false;
					__Result.strMessage="Maybe your Certificate Util cannot be used by this program.\nThe first line of the input file is not right.\nREQR: -----BEGIN CERTIFICATE-----\nYOUR: "+__ConvIn+"\n";
					return __Result;
				}
				__bSetup=true;
				__InputStream.getline(__In,sizeof(__In));
				__ConvIn=__In;
				__Length=__ConvIn.length();
				continue;
			}
			__Out="";
			__Proced++;
			for(int i=0;i<__Length;i++)
			{
				__Out+=__ValidString[__BaseToValid[__BaseToInt[(int)__In[i]]]];
			}
			__OutputStream<<__Out<<endl;
			if(!(__Proced&255))
			{
				printf("\rOver %d lines converted.",__Proced);
			}
			__InputStream.getline(__In,sizeof(__In));
			__ConvIn=__In;
			__Length=__ConvIn.length();
		}
		__OutputStream<<":eof"<<endl;
		printf("\n***End file successfully.***\n");
		__InputStream.close();
		printf("***Clearing up...***\n");
		system(__Command.c_str());
		printf("***Clear up is finished.\n");
		__Result.bSuccess=true;
		__Result.strMessage="Successfully wrote the indexes of the file \""+__InputFileName+"\".\n";
		return __Result;
	}
}

bool EncodeFileSet(int __Count,string *__FileSet,string __OutputFileName)
{
	__EncodeResult __Temp;
	__OutputStream.open(__OutputFileName,ios::out);
	__Temp=__Encoder::__prebuild(__OutputStream);
	SetColor(10);
	printf("%s",__Temp.strMessage.c_str());
	SetColor();
	for(int i=0;i<__Count;i++)
	{
		__Temp=__Encoder::__pr_001(__FileSet[i],__OutputStream);
		if(__Temp.bSuccess)
		{
			SetColor(10);
			printf("%s",__Temp.strMessage.c_str());
			SetColor();
		}
		else
		{
			SetColor(9);
			printf("%s",__Temp.strMessage.c_str());
			SetColor();
		}
	}
	__Temp=__Encoder::__endfile(__OutputStream);
	__OutputStream.close();
	SetColor(10);
	printf("%s",__Temp.strMessage.c_str());
	SetColor();
	return false;
}

namespace __Decoder
{
	__DecodeResult __pr_001(fstream &__InputStream,string __OutputFileName)
	{
		__DecodeResult __Result;
		fstream __OutputStream;
		__OutputStream.open(__OutputFileName+".tmp",ios::out);
		printf("*****Proccessing file \"%s\"...*****\n***Reading Mask...***\n",__OutputFileName.c_str());
		__InputStream>>__Mask;
		// printf("%s\n",__Mask.c_str());
		printf("***Read mask done.***\n***Converting the mask to InnerFormat...***\n");
		__InitFromMask();
		printf("***Convert finished.***\n***Writing certificate header...***\n[1/1]Write static Windows header...\n");
		__OutputStream<<"-----BEGIN CERTIFICATE-----\n";
		printf("***Successfully to write header.***\n***Converting the file...***\nOver 0 lines wrote.");
		string __Temp="Nothing",__Out;
		int __Length,__Proced=0;
		// for(int i=0;i<95;i++) printf("%d\n",__ValidToInt[i]);
		while(__Temp!=":eof")
		{
			__Proced++;
			__InputStream>>__Temp;
			if(__Temp==":eof")
			{
				continue;
			}
			__Length=__Temp.length();
			__Out="";
			for(int i=0;i<__Length;i++)
			{
				__Out+=__BaseString[__ValidToBase[__ValidToInt[(int)__Temp[i]]]];
			}
			__OutputStream<<__Out<<endl;
			if(!(__Proced&255))
			{
				printf("\rOver %d lines wrote.",__Proced);
			}
		}
		printf("\n***Successfully to decode the file.***\n***Writin certificate footer...***\n[1/1]Write static Windows footer...\n");
		__OutputStream<<"-----END CERTIFICATE-----\n";
		__OutputStream.close();
		printf("***Successfully to write footer.***\n***Converting the file from Base64...***\n");
		string __Command="certutil -f -decode \""+__OutputFileName+".tmp\" \""+__OutputFileName+"\"";
		system(__Command.c_str());
		printf("***Successfully to decode from Base64.***\n***Deleting temps...***\n");
		__Command="del /f /s /q \""+__OutputFileName+".tmp\"";
		system(__Command.c_str());
		printf("***Successfully to decode file \"%s\"!***\n",__OutputFileName.c_str());
		__Result.bSuccess=true;
		__Result.strMessage="Successfully relaxed the indexes of the file \""+__OutputFileName+"\".\n";
		return __Result;
	}

	__DecodeResult __mainexec(fstream &__InputStream)
	{
		__DecodeResult __Result;
		string __Head;
		printf("*****Decoding file public header...*****\n");
		__InputStream>>__Head;
		if(__Head!="Vencrypt?")
		{
			__Result.bSuccess=false;
			__Result.strMessage="The file header is not a Vencrypt Archive.\n";
			return __Result;
		}
		__InputStream>>__Head;
		bool hasDn=false;
		if(__Head!=">Match-FileInfo")
		{
			if(__Head!=">New-File"&&__Head!=">End-Matches")
			{
				SetColor(9);
				printf("[Error] Unknown argument");
			}
			SetColor(11);
			printf("[Warning] FileInfo is not seted, we cannot know your generator.\n");
			SetColor();
		}
		else
		{
			__InputStream>>__Head;
			while(__Head!=">New-File"&&__Head!=">End-Matches")
			{
				if(__Head==":Change")
				{
					__InputStream>>__Head;
					if(__Head=="Generator-Display-Name")
					{
						if(hasDn)
						{
							SetColor(9);
							printf("[Error] You only can change the display name of your generator for 1 time.\n");
							SetColor();
						}
						else
						{
							hasDn=true;
							SetColor(3);
							char Buf[512],Temp1;
							__InputStream>>Temp1;
							__InputStream.getline(Buf,sizeof(Buf));
							printf("[Note] Got the information about the generator of the file.\nThis file is generated by %c%s\n",Temp1,Buf);
							SetColor();
						}
					}
					else
					{
						SetColor(9);
						printf("[Error] Undefined properties \"%s\"! This error is NOT important, the program will ignore it.\n",__Head.c_str());
						SetColor();
					}
				}
				else
				{
					SetColor(9);
					printf("[Error] Undefined method \"%s\" in Match-FileInfo! This error is NOT important, the program will ignore it.\n",__Head.c_str());
					SetColor();
				}
				__InputStream>>__Head;
			}
			
		}
		string __FileType,__FileName;
		int __Branch,__Version;
		char __FileNameBuf[1024];
		__DecodeResult __Temp;
		while(__Head!=">End-Matches")
		{
			if(__Head==">New-File")
			{
				__InputStream>>__Head;
				__InputStream>>__FileType;
				__InputStream>>__Head;
				__InputStream.getline(__FileNameBuf,sizeof(__FileNameBuf));
				__FileName=__FileNameBuf;
				__FileName=__FileName.substr(1,__FileName.length()-1);
				__FileName+="."+__FileType;
				__InputStream>>__Head;
				__InputStream>>__Branch;
				__InputStream>>__Head;
				__InputStream>>__Version;
				if(__Branch==0)
				{
					if(__Version==0)
					{
						__Temp=__pr_001(__InputStream,__FileName);
						if(__Temp.bSuccess)
						{
							SetColor(10);
							printf("%s",__Temp.strMessage.c_str());
							SetColor();
						}
						else
						{
							SetColor(9);
							printf("%s",__Temp.strMessage.c_str());
							SetColor();
						}
					}
					else
					{
						SetColor(9);
						printf("[Error] Pre-Release %d is too new! The maxium support of this version is Pre-Release 0.\n",__Version);
						SetColor();
					}
				}
				else
				{
					SetColor(9);
					printf("[Error] Branch %d is too new! The maxium support of this version is 0(Pre-Release).\n",__Branch);
					SetColor();
				}
			}
			else
			{
				SetColor(9);
				printf("[Error] Undefined \"%s\"! This error is NOT important, the program will ignore it.\n",__Head.c_str());
				SetColor();
			}
			__InputStream>>__Head;
		}
		__Result.bSuccess=true;
		__Result.strMessage="Successfully to decrypt files.\n";
		return __Result;
	}
}

bool DecodeFile(string __InputFileName)
{
	if(!__bInit)
	{
		printf("***Program is not ready, preparing environment...***\n");
		__InitSystem();
		printf("***Successfully to init.***\n");
	}
	__DecodeResult __Temp;
	fstream __InputStream;
	if(!__InputStream.good()) return true;
	__InputStream.open(__InputFileName,ios::in);
	__Temp=__Decoder::__mainexec(__InputStream);
	SetColor(10);
	printf("%s",__Temp.strMessage.c_str());
	SetColor();
	__InputStream.close();
	return false;
}

#endif
#include "venc.cpp"

int main(int argc,char *argv[])
{
	int PreId=0,Count=0;
	string TargetSet[1024];
	string Output="output.vnecr";
	string Input="%%%";
	bool bOutput=false;
	string Temp=argv[1];
	if(Temp=="-e"||Temp=="--encode")
	{
		for(int i=2;i<argc;i++)
		{
			Temp=argv[i];
			if(Temp=="-i"||Temp=="--input")
			{
				if(PreId)
				{
					SetColor(9);
					printf("E:0x00000001\n");
					SetColor();
					return 1;
				}
				PreId=1;
			}
			else if(Temp=="-o"||Temp=="--output")
			{
				if(PreId)
				{
					SetColor(9);
					printf("E:0x00000002\n");
					SetColor();
					return 1;
				}
				PreId=2;
			}
			else
			{
				if(!PreId)
				{
					SetColor(9);
					printf("E:0x00000003\n");
					SetColor();
					return 1;
				}
				if(PreId==1)
				{
					TargetSet[Count]=Temp;
					Count++;
				}
				else
				{
					if(bOutput)
					{
						SetColor(9);
						printf("E:0x00000004\n");
						SetColor();
						return 1;
					}
					bOutput=true;
					Output=Temp;
				}
				PreId=0;
			}
		}
		if(Count==0)
		{
			SetColor(9);
			printf("E:0x00000005\n");
			SetColor();
			return 1;
		}
		return (int)EncodeFileSet(Count,TargetSet,Output);
	}
	else if(Temp=="-d"||Temp=="--decode")
	{
		if(argc!=3)
		{
			SetColor(9);
			printf("E:0x00000006\n");
			SetColor();
			return 1;
		}
		Input=argv[2];
		return (int)DecodeFile(Input);
	}
}
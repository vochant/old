New-SelfSignedCertificate -Type Custom -Subject "CN=Administrator" -KeyUsage DigitalSignature -FriendlyName "9bc4abe5-bf75-4f82-a022-445552f71f3f" -CertStoreLocation "Cert:\LocalMachine\My" -TextExtension @("2.5.29.37={text}1.3.6.1.5.5.7.3.3", "2.5.29.19={text}")
Get-ChildItem Cert:\LocalMachine\My | Format-Table Thumbprint
$pwd = ConvertTo-SecureString -String 123456 -Force -AsPlainText
$a = Read-Host "����������Ǹ��ַ���"
Export-PfxCertificate -cert "Cert:\LocalMachine\My\$a" -FilePath .\output.pfx -Password $pwd
.\SignTool.exe sign /fd SHA256 /a /f .\output.pfx /p 123456 .\uwp.appxbundle
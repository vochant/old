#include <windows.h>
#include <iostream>
#include <ctime>
#include <cstdlib>
#include <cstdio>
#include <fstream>
#include <map>
#include <vector>
#include <string>

#define IDB_GENERATE

HWND hwnd;

using namespace std;

int Spp;
HINSTANCE HIG;
HWND HWGE;

int Prev;

int Usage[64];
char Title[64][32];
string str[32];
int Count,Blocked;
int Hard,Logged=20;

HWND Gen,Exit,Group,Yes,No,Okey,Bar,Tex;

fstream fs;

void CreateLog(LPCSTR Log)
{
	CreateWindowEx(NULL,"static",Log,WS_VISIBLE|WS_CHILD,10,Logged,240,20,Group,NULL,HIG,NULL);
	Logged+=20;
	if(Logged==340)
	{
		Logged=20; 
	}
}

char Strset[2][32]={"��ǰģʽ:G","��ǰģʽ:Y"};

LRESULT CALLBACK WndProc(HWND hwnd,UINT Message,WPARAM wParam,LPARAM lParam)
{
	switch(Message)
	{
		case WM_COMMAND:
		{
			switch((int)wParam)
			{
				case 101:
				{
					if(Blocked==Count)
					{
						Blocked=0;
						for(int i=0;i<Count;i++)
						{
							Usage[i]=0;
						}
					}
					int Xid=-1;
					while((Usage[Xid]&&Hard)||Xid==-1||Xid==Prev)
					{
						Xid=rand()%(Count);
					}
					Blocked++;
					Prev=Xid;
					Usage[Xid]=1;
					fs.open("block.txt",ios::out);
					fs<<Prev<<endl;
					for(int i=0;i<Count;i++)
					{
						fs<<Usage[i]<<endl;
					}
					CreateLog("[Main] app.generate");
					fs.close();
					SetWindowText(Bar,(LPCSTR)Title[Xid]); 
					break;
				}
				case 102:
				{
					CreateLog("[Main] exit");
					PostQuitMessage(0);
					break; 
				}
				case 104:
				{
					CreateLog("[Settings] mode.0");
					SetWindowText(Tex,(LPCSTR)Strset[0]);
					Hard=1;
					break;
				}
				case 105:
				{
					CreateLog("[Settings] mode.1");
					SetWindowText(Tex,(LPCSTR)Strset[1]);
					Hard=0;
					break;
				}
				case 106:
				{
					CreateLog("[Settings] save");
					fs.open("options.txt",ios::out);
					fs<<Spp<<" "<<Hard;
					fs.close();
					break;
				}
				case 107:
				{
					CreateLog("[Dlg] helper");
					MessageBox(NULL,"Q:����ĳ���Ϊʲô������?\nA:default.txt��ҪANSI����.\nQ:����͸�����ʲô����?\nA:����������Ҳ����Ч,��Ҫʹ�ر�ʱ��ʧЧ��Ҫ����.\nQ:Ȼ����Ҫ�ʵĲ�����Щ...\nA:������!\nQ:��ô������ô��ϵ?\nA:����chenyuanxi1029@163.com\n  ΢��chenyuanxi1029\n  QQ50600770\n  Bվ660602059","Helper",MB_OK);
					break; 
				}
				case 108:
				{
					CreateLog("[Dlg] about");
					MessageBox(NULL,"����:MRKNVOID(��Ԫ��)\n��������:C++\n��������:Dev-C++\n��������:��WinAPI\n���ֽ̳�����������.","About",MB_OK);
					break; 
				}
				default:
				{
					break;
				}
			}
			break;
		}
		case WM_DESTROY:
		{
			PostQuitMessage(0);
			break;
		}
		case WM_CREATE:
		{
			Gen=CreateWindowEx(0,"Button","��ʼ",WS_VISIBLE|WS_CHILD|BS_PUSHBUTTON,60,0,150,50,hwnd,(HMENU)101,HIG,NULL);
			Exit=CreateWindowEx(0,"Button","�˳�",WS_VISIBLE|WS_CHILD|BS_PUSHBUTTON,60,50,150,50,hwnd,(HMENU)102,HIG,NULL);
			CreateWindowEx(0,"button","����(ʵʱ����,���Զ�����)",WS_CHILD|WS_VISIBLE|BS_GROUPBOX,10,160,300,150,hwnd,(HMENU)103,HIG,NULL);
			Yes=CreateWindowEx(0,"button","��ƽģʽ(����ѡ��δѡ�е�) <G>",WS_CHILD|WS_VISIBLE|BS_LEFT|BS_AUTORADIOBUTTON,25,185,250,30,hwnd,(HMENU)104,HIG,NULL);
			No=CreateWindowEx(0,"button","һ��ģʽ(��ȫ���) <Y>",WS_CHILD|WS_VISIBLE|BS_LEFT|BS_AUTORADIOBUTTON,25,215,250,30,hwnd,(HMENU)105,HIG,NULL);
			Okey=CreateWindowEx(0,"Button","��������",WS_VISIBLE|WS_CHILD|BS_PUSHBUTTON,25,245,150,60,hwnd,(HMENU)106,HIG,NULL);
			Bar=CreateWindowEx(0,"edit","��û������",WS_CHILD|WS_VISIBLE|WS_BORDER|ES_LEFT,10,350,150,25,hwnd,NULL,HIG,NULL);
			CreateWindowEx(0,"Button","����",WS_VISIBLE|WS_CHILD|BS_PUSHBUTTON,60,100,75,50,hwnd,(HMENU)107,HIG,NULL);
			CreateWindowEx(0,"Button","����",WS_VISIBLE|WS_CHILD|BS_PUSHBUTTON,135,100,75,50,hwnd,(HMENU)108,HIG,NULL);
			Tex=CreateWindowEx(0,"static",(LPCSTR)Strset[1-Hard],WS_VISIBLE|WS_CHILD,180,265,100,20,hwnd,NULL,HIG,NULL);
			Group=CreateWindowEx(0,"button","��־",WS_CHILD|WS_VISIBLE|BS_GROUPBOX,320,20,300,360,hwnd,NULL,HIG,NULL);
			CreateLog("[Msg] create");
			break;
		}
		case WM_CLOSE:
		{
			if(!Spp)
			{
				return DefWindowProc(hwnd,Message,wParam,lParam);
			}
			break;
		}
		default:
		{
			return DefWindowProc(hwnd,Message,wParam,lParam);
		}
	}
	return 0;
}

int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nCmdShow)
{
	fs.open("default.txt",ios::in);
	fs>>Count;
	string Tmp;
	for(int i=0;i<Count;i++)
	{
		fs>>Tmp;
		sprintf(Title[i],"����:%s",Tmp.c_str());
	}
	fs.close();
	fs.open("options.txt",ios::in);
	fs>>Spp>>Hard;
	fs.close();
	fs.open("block.txt",ios::in);
	fs>>Prev;
	for(int i=0;i<Count;i++)
	{
		fs>>Usage[i];
		if(Usage[i])
		{
			Blocked++;
		}
	}
	fs.close();
	srand(time(0));
	rand();
	WNDCLASSEX wc;
	HWND hwnd;
	MSG Msg;
	memset(&wc,0,sizeof(wc));
	wc.cbSize=sizeof(WNDCLASSEX);
	wc.lpfnWndProc=WndProc;
	wc.hInstance=hInstance;
	wc.hCursor=LoadCursor(NULL,IDC_ARROW);
	wc.hbrBackground=(HBRUSH)(COLOR_WINDOW);
	wc.lpszClassName="WindowClass";
	wc.hIcon=LoadIcon(NULL,IDI_APPLICATION);
	wc.hIconSm=LoadIcon(NULL,IDI_APPLICATION);
	RegisterClassEx(&wc);
	hwnd=CreateWindowEx(WS_EX_CLIENTEDGE,"WindowClass","RG - by MRKNVOID",WS_VISIBLE|WS_SYSMENU|WS_OVERLAPPED|WS_CAPTION|WS_MINIMIZEBOX,CW_USEDEFAULT,CW_USEDEFAULT,640,480,NULL,NULL,hInstance,NULL);
//	CreateWindowEx(0,"BUTTON","��ʼ",WS_VISIBLE|WS_CHILD|BS_PUSHBUTTON,100,100,100,100,hwnd,(HMENU)101,hInstance,NULL);
	if(hwnd==NULL)
	{
		return 0;
	}
	HIG=hInstance; 
	while(GetMessage(&Msg,NULL,0,0)>0)
	{
		TranslateMessage(&Msg);
		DispatchMessage(&Msg);
	}
	return Msg.wParam;
}


#ifndef WORDLE_CC_FUNCTIONS_LIB
#define WORDLE_CC_FUNCTIONS_LIB

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <iostream>
#include <string>
#include <map>
#include <fstream>
#include <ctime>
#include <windows.h>
#include <cmath>
#define B 1
#define G 2
#define R 4
#define I 8
#define M 12953

#define Volch(VK_NONAME) ((GetAsyncKeyState(VK_NONAME)&0x8000)?1:0)
#define MoveCur SetConsoleCursorPosition

#define MOVL 75
#define MOVR 77
#define MOVU 72
#define MOVD 80


using namespace std;

int Pwlth;
map<int,int> Pwlist;

HANDLE hOut;
map<int,string> Idm;
map<string,bool> Chs;
CONSOLE_CURSOR_INFO CursorInfo;
COORD crd;
bool AUW;
string Answer;
int char_status[26];
string user_select;

map<int,string> History;
map<int,int> HistoryStatus[5];
map<string,bool> real_users;

int hists;

int Gentuid(string str)
{
	int a=0;
	for(int i=0;i<str.length();i++)
	{
		a^=(int)str[i];
	}
	return a;
}

string ICTS(int *a,int SZ)
{
	string ret="";
	for(int i=0;i<SZ;i++)
	{
		ret+=(char)a[i];
	}
	return ret;
}

int* SCTI(string str)
{
	int *ret;
	for(int i=0;i<str.length();i++)
	{
		ret[i]=(int)str[i];
	}
	return ret;
}

int* DEP(string udep,string user)
{
	int* ret;
	ret[0]=udep.length();
	int uid=Gentuid(user);
	for(int i=0;i<udep.length();i++)
	{
		ret[i+1]=(((int)udep[i])^uid);
	}
	return ret;
}

struct HistoryType
{
	int times[6];
	string Ans;
	int gstp;
	
	friend bool operator<(HistoryType a,HistoryType b)
	{
		for(int i=0;i<6;i++)
		{
			if(a.times[i]<b.times[i]) return true;
			if(a.times[i]>b.times[i]) return false;
		}
		return a.gstp==b.gstp?(a.Ans<b.Ans):(a.gstp<b.gstp);
	}
	friend bool operator>(HistoryType a,HistoryType b)
	{
		for(int i=0;i<6;i++)
		{
			if(a.times[i]>b.times[i]) return true;
			if(a.times[i]<b.times[i]) return false;
		}
		return a.gstp==b.gstp?(a.Ans>b.Ans):(a.gstp>b.gstp);
	}
};

map<int,HistoryType> histb;
map<int,bool> imposWords;

struct FormatMsg
{
	string sMsg;
	int Color;
};

struct UserOptions
{
	bool SearchEngine;
	bool AutoHistory;
	bool Password;
	string strPassword;
	int Score;
}CurrentUser;

void Clear()
{
	system("cls");
}

void MoveCursor(int X,int Y)
{
	crd.X=X;
	crd.Y=Y;
	MoveCur(hOut,crd);
}

void SetColor(int fg=15,int bg=0)
{
	SetConsoleTextAttribute(hOut,(bg<<4)|fg);
}

void ShowFM(FormatMsg msg)
{
	SetColor(msg.Color);
	cout<<msg.sMsg;
	SetColor();
}

void InitProg()
{
	srand((unsigned int)time(NULL));
	rand();
	hOut=GetStdHandle(STD_OUTPUT_HANDLE);
	GetConsoleCursorInfo(hOut,&CursorInfo);
	Idm.clear();
	Chs.clear();
	fstream fs;
	fs.open("list.mpt",ios::in);
	string _temp;
	for(int i=0;i<M;i++)
	{
		fs>>_temp;
		Idm[i]=_temp;
		Chs[_temp]=true;
	}
	fs.close();
}

void ShowCursor(bool doShow=false)
{
	CursorInfo.bVisible=doShow;
	SetConsoleCursorInfo(hOut,&CursorInfo);
}

int GetSwitch(string Alrt[],int iCount,string Title)
{
	Clear();
	int Chsed=0,ChsTemp=-1,shA1=0,mw=0,Page=0,Pages=iCount/20+1;
	for(int i=0;i<iCount;i++)
	{
		mw=max(mw,(int)Alrt[i].length()-2);
	}
	ShowCursor();
	char chSel='a';
	int Pt;
	while(chSel!='\r')
	{
		if(chSel=='x') return -1;
		if(chSel==75||chSel==72||chSel=='w'||chSel=='a')
		{
			if(Chsed>0) Chsed--;
		}
		if(chSel==77||chSel==80||chSel=='s'||chSel=='d')
		{
			if(Chsed<iCount-1) Chsed++;
		}
		if(chSel=='k'&&Page)
		{
			Page--;
			Chsed-=20;
		}
		if(chSel=='l'&&Page<Pages-1)
		{
			Page++;
			Chsed+=20;
		}
		if(ChsTemp!=Chsed)
		{
			if(Page!=Pt)
			{
				Clear();
				Pt=Page;
			}
			MoveCursor(0,0);
			SetColor();
			printf("(%s):Selector\n",Title.c_str());
			ChsTemp=Chsed;
			for(int i=20*Page;i<min(iCount-(20*Page),20)+20*Page;i++)
			{
				if(i==Chsed){
					SetColor(R|G|I);
					printf("[ ");
					SetColor(15);
				}else{
					SetColor();
					printf("  ");
					SetColor();
				}
				if(i==Chsed) SetColor(G|I);
				else SetColor();
				cout<<Alrt[i];
				SetColor();
				 if(i==Chsed){
				 	SetColor(R|G|I);
					printf(" ]");
					SetColor(15,I);
				}else{
					SetColor();
					printf("  ");
					SetColor();
				}
				SetColor(0);
				for(int j=0;j<mw+2-(int)Alrt[i].length();j++) printf(" ");
				SetColor();
				printf("\n");
			}
			if(Pages>1)
			{
				printf("\n\n[Multi-page]k=PrevPg,l=NextPg.\nPage:%d/%d iRange:%d/%d(%d)",Page+1,Pages,20*Page,min(iCount-(20*Page),20)+20*Page,iCount);
			}
		}
		chSel=getch();
	}
	while(Volch(VK_DOWN));
	ShowCursor(true);
	return Chsed;
}

bool CheckString(string str)
{
	#ifdef EnableAdvancedMode
	return CheckStringAdvanced(str);
	#else
	if((!AUW)&&(!Chs[str])) return false;
	if(str.length()!=5) return false;
	for(int i=0;i<5;i++)
	{
		if(!(str[i]>='a'&&str[i]<='z')) return false;
	}
	return true;
	#endif
}

int Xrand()
{
	return ((rand()%32768)<<16)|(rand()%65536);
}

void Delay(int time)
{ 
	clock_t now=clock(); 
	while(clock()-now<time); 
}

void SlowPut(string str)
{
	ShowCursor();
	for(int i=0;i<str.length();i++)
	{
		cout<<str[i];
		Delay(125);
	}
	Delay(375);
	ShowCursor(true);
}

void PutList()
{
	string str="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	int mnss=0;
	SetColor();
	for(int i=0;i<4;i++)
	{
		for(int j=0;j<7;j++)
		{
			if((i*7+j==17)||(i*7+j==24))
			{
				printf("  ");
				mnss++;
				continue;
			}
			if(char_status[i*7+j-mnss]==1)
			{
				printf("  ");
				continue;
			}
			if(char_status[i*7+j-mnss]==0)
			{
				SetColor();
			}
			if(char_status[i*7+j-mnss]==2)
			{
				SetColor(G|R|I);
			}
			if(char_status[i*7+j-mnss]==3)
			{
				SetColor(G|I);
			}
			cout<<str[i*7+j-mnss]<<' ';
		}
		printf("\n");
	}
}

void NewType(int status,int id)
{
	char_status[id]=max(char_status[id],status);
}

void BasicPoswordSort(string str,int Uin[5],int rl)
{
	string strCnt;
	int ItemCount[26];
	for(int i=0;i<M;i++)
	{
		memset(ItemCount,0,sizeof(ItemCount));
		strCnt=Idm[i];
		int stat[5];
		for(int j=0;j<5;j++)
		{
			ItemCount[(int)(strCnt[j]-'a')]++;
			stat[j]=1;
		}
		if(rl==3)
		{
			for(int j=0;j<5;j++)
			{
				if(str[j]==strCnt[j])
				{
					stat[j]=3;
					ItemCount[(int)(str[j]-'a')]--;
				}
			}
		}
		if(rl!=1)
		{
			for(int j=0;j<5;j++)
			{
				if(ItemCount[(int)(str[j]-'a')]&&stat[j]!=3)
				{
					ItemCount[(int)(str[j]-'a')]--;
					stat[j]=2;
				}
			}
		}
		if(rl==1)
		{
			int crts=0;
			for(int j=0;j<5;j++)
			{
				if(ItemCount[(int)(str[j]-'a')])
				{
					stat[crts++]=2;
					ItemCount[(int)(str[j]-'a')]--;
				}
			}
		}
		for(int j=0;j<5;j++)
		{
			if(stat[j]!=Uin[j]) imposWords[i]=true;
		}
	}
}

int ExtraCount;
map<string,bool> Exl;
map<int,string> Exws;
bool ExWordBeAnswer=false;

bool CheckStringAdvanced(string str)
{
	if((!AUW)&&(!Chs[str])&&(!Exl[str])) return false;
	if(str.length()!=5) return false;
	for(int i=0;i<5;i++)
	{
		if(!(str[i]>='a'&&str[i]<='z')) return false;
	}
	return true;
}


void RegistyAddons()
{
	
}

#endif

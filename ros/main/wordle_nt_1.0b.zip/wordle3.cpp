#include "wcfunctions.h"

int main(int argc,char *argv[])
{
	if(argc>1)
	{
		string Det2=argv[1];
		if(Det2=="--import-addons")
		{
			return 0;
		}
	}
	int rl;
	CurrentUser.AutoHistory=false;
	CurrentUser.Score=0;
	CurrentUser.SearchEngine=true;
	CurrentUser.strPassword="PLEASEDZTBGZSCZFCDDMPL";
	fstream ufs;
	ufs.open("./Data/root.mpt",ios::in);
	string NextUser;
	real_users.clear();
	while(ufs>>NextUser)
	{
		real_users[NextUser]=true;
	}
	ufs.close();
	InitProg();
	SetColor();
	system("title Wordle NT 1.0b");
	user_select="default";
	bool Lock=true;
	int score;
	while(1)
	{
		string Selct[32]={"Start a new game","Play history","Plugin manager","Log manager","Word Viewer","Exit"};
		int Rootmd=GetSwitch(Selct,6,"Main");
		switch(Rootmd)
		{
			case -1:
			{
				return 0;
			}
			case 0:
			{
				Clear();
				AUW=false;
				Answer=Idm[rand()%M];
				int CreateMode;
				Selct[0]="Wordle(Basic)";
				Selct[1]="Wordle(Advanced)";
				CreateMode=GetSwitch(Selct,2,"Game Mode");
				bool bSucs=true;
				if(CreateMode==-1) break;
				rl=3;
				string SEL1[]={"1:Number only","2:Fine","3:Detail"};
				rl=GetSwitch(SEL1,3,"Result Mode")+1;
				if(rl==0) break;
				switch(CreateMode)
				{
					case 2:
					{
						bSucs=false;
						break;
					}
					case 1:
					{
						Selct[0]="Set answer";
						Selct[1]="Allow unreal words:";
						Selct[2]="Save changes";
						int Setmd=-1;
						string ConStr[2]={"Open","Close"};
						int Ach=1;
						while(Setmd!=2)
						{
							Selct[1]=Selct[1].substr(0,19)+ConStr[Ach];
							Setmd=GetSwitch(Selct,3,"Advanced Game");
							switch(Setmd)
							{
								case 0:
								{
									Clear();
									printf("Use a-z input a 5 charators word:");
									string ans="_";
									while(!CheckString(ans))
									{
										MoveCursor(0,1);
										cin>>ans;
										if(!CheckString(ans))
										{
											MoveCursor(0,2);
											SetColor(R|I);
											printf("Error,please look rules!");
											SetColor();
										}
									}
									Answer=ans;
									break;
								}
								case 1:
								{
									AUW=!AUW;
									Ach=1-Ach;
									break;
								}
								default:
								{
									break;
								}
							}
							
						}
					}
				}
				if(bSucs)
				{
					string UserInput="_";
					memset(char_status,0,sizeof(char_status));
					bool isCheat=false;
					int GuessCnt=0;
					int Xcnt=9;
					while(UserInput!=Answer)
					{
						Clear();
						PutList();
						SetColor();
						printf("\nHistory guess:\n");
						Xcnt=9;
						for(int i=0;i<GuessCnt;i++)
						{
							if(i%3==0&&i!=0)
							{
								Xcnt++;
								printf("\n");
							}
							for(int j=0;j<5;j++)
							{
								if(rl==3)
								{
									if(HistoryStatus[j][i]==1) SetColor(R|G|B|I);
									if(HistoryStatus[j][i]==2) SetColor(R|G|I);
									if(HistoryStatus[j][i]==3) SetColor(G|I);
								}
								if(rl==2)
								{
									if(HistoryStatus[j][i]==1) SetColor(R|G|B|I);
									if(HistoryStatus[j][i]==2) SetColor(G|B|I);
								}
								if(rl==1)
								{
									if(HistoryStatus[j][i]==1) SetColor(R|G|B|I);
									if(HistoryStatus[j][i]==2) SetColor(R|B|I);
								}
								cout<<History[i][j];
		 					}
		 					printf(" ");
						}
						if(!GuessCnt)
						{
							SetColor(R|G|I);
							printf("History is empty");
							SetColor();
						}
						SetColor();
						MoveCursor(0,Xcnt-1);
						printf("Please guess:");
						UserInput="_";
						bool doContinue=false;
						while(!CheckString(UserInput))
						{
							MoveCursor(0,Xcnt);
							cin>>UserInput;
							if(UserInput=="$debug")
							{
								int DebugMode;
								cin>>DebugMode;
								isCheat=true;
								if(DebugMode==1)
								{
									MoveCursor(0,Xcnt);
									cout<<"[MAIN/DEBUG] Answer is "<<Answer;
									Delay(2000);
									doContinue=true;
									MoveCursor(0,Xcnt);
									cout<<"                                  ";
									break;
								}
							}
							else if(!CheckString(UserInput))
							{
								MoveCursor(0,Xcnt+1);
								SetColor(R|I);
								printf("Please look rules");
								SetColor();
							}
						}
						if(doContinue) continue;
						MoveCursor(0,Xcnt+1);
						printf("                     ");
						MoveCursor(0,Xcnt);
						int ItemCount[26];
						memset(ItemCount,0,sizeof(ItemCount));
						for(int i=0;i<5;i++)
						{
							ItemCount[(int)(Answer[i]-'a')]++;
							HistoryStatus[i][GuessCnt]=1;
						}
						if(rl==3)
						{
							for(int i=0;i<5;i++)
							{
								if(UserInput[i]==Answer[i])
								{
									HistoryStatus[i][GuessCnt]=3;
									ItemCount[(int)(UserInput[i]-'a')]--;
									NewType(3,(int)(UserInput[i]-'a'));
								}
							}
						}
						if(rl!=1)
						{
							for(int i=0;i<5;i++)
							{
								if(ItemCount[(int)(UserInput[i]-'a')]&&HistoryStatus[i][GuessCnt]!=3)
								{
									ItemCount[(int)(UserInput[i]-'a')]--;
									NewType(2,(int)(UserInput[i]-'a'));
									HistoryStatus[i][GuessCnt]=2;
								}
								else if(UserInput[i]!=Answer[i]&&HistoryStatus[i][GuessCnt]!=3)
								{
									HistoryStatus[i][GuessCnt]=1;
									NewType(1,(int)(UserInput[i]-'a'));
								}
							}
						}
						if(rl==1)
						{
							int crts=0;
							for(int i=0;i<5;i++)
							{
								HistoryStatus[i][GuessCnt]=1;
								if(ItemCount[(int)(UserInput[i]-'a')])
								{
									HistoryStatus[crts++][GuessCnt]=2;
									ItemCount[(int)(UserInput[i]-'a')]--;
								}
							}
						}
						History[GuessCnt++]=UserInput;
					}
					MoveCursor(0,Xcnt+2);
					SetColor(G|I);
					printf("Success!");
					SetColor();
					Delay(1000);
					fstream wth;
					bool writeNow=false;
					if(CurrentUser.AutoHistory) writeNow=true;
					if(!writeNow&&user_select!="default")
					{
						printf("Write this history?(Y=true,others=false)\n");
						string MODE;
						cin>>MODE;
						if(MODE=="Y") writeNow=true;
					}
					if(writeNow)
					{
						wth.open((".\\data\\"+user_select+"\\history.mpt").c_str(),ios::app|ios::out);
						time_t Timer1;
						tm *Timer2;
						time(&Timer1);
						Timer2=localtime(&Timer1);
						wth<<Xrand()<<" "<<rl<<" "<<Timer2->tm_year+1900<<" "<<Timer2->tm_mon+1<<" "<<Timer2->tm_mday<<" "<<Timer2->tm_hour<<" "<<Timer2->tm_min<<" "<<Timer2->tm_sec<<endl;
						wth<<Answer<<" "<<GuessCnt<<endl;
						for(int i=0;i<GuessCnt;i++)
						{
							wth<<History[i];
							for(int j=0;j<5;j++)
							{
								wth<<' '<<HistoryStatus[j][i];
							}
							wth<<endl;
						}
						wth.close();
					}
					if(!isCheat)
					{
						if(GuessCnt<3) score+=5;
						else if(GuessCnt<4) score+=3;
						else if(GuessCnt<7) score+=1;
					}
					Clear();
				}
				break;
			}
			case 1:
			{
				Clear();
				if(user_select=="default")
				{
					printf("Please log a account!\n");
					Delay(1000);
					break;
				}
				system("del temp.mpt");
				system(("copy .\\data\\"+NextUser+"\\history.mpt temp.mpt").c_str());
				fstream hisrd;
				hisrd.open("temp.mpt",ios::in);
				hists=0;
				histb.clear();
				string hasNex;
				string Histp[65535];
				int retl[65536];
				map<int,string> Gses[255];
				map<int,short> Gsty[255][5];
				int CntHist,movcnt,nxcnt;
				while(hisrd>>hasNex)
				{
					hisrd>>retl[hists];
					for(int i=0;i<6;i++)
					{
						hisrd>>histb[hists].times[i];
					}
					hisrd>>histb[hists].Ans;
					hisrd>>histb[hists].gstp;
					for(int kk=0;kk<histb[hists].gstp;kk++)
					{
						hisrd>>Gses[kk][hists];
						for(int kj=0;kj<5;kj++)
						{
							hisrd>>Gsty[kk][kj][hists];
						}
					}
					hists++;
					Histp[hists-1]="history id#"+hasNex;
				}
				hisrd.close();
				Histp[hists]="Exit";
				int hiscs=-1;
				while(hiscs!=hists)
				{
					hiscs=GetSwitch(Histp,hists+1,"Histories");
					if(hiscs==hists||hiscs==-1) break;
					Clear();
					cout<<"Play time:"<<histb[hiscs].times[0]<<"/"<<histb[hiscs].times[1]<<"/"<<histb[hiscs].times[2]<<" "<<histb[hiscs].times[3]<<":"<<histb[hiscs].times[4]<<":"<<histb[hiscs].times[5]<<endl;
					cout<<"Answer is "<<histb[hiscs].Ans<<" you used "<<histb[hiscs].gstp<<" guesses\n";
					for(int i=0;i<histb[hiscs].gstp;i++)
					{
						for(int j=0;j<5;j++)
						{
							if(retl[hiscs]==3)
							{
								if(Gsty[i][j][hiscs]==1) SetColor();
								if(Gsty[i][j][hiscs]==2) SetColor(R|G|I);
								if(Gsty[i][j][hiscs]==3) SetColor(G|I);
							}
							if(retl[hiscs]==2)
							{
								if(Gsty[i][j][hiscs]==1) SetColor();
								if(Gsty[i][j][hiscs]==2) SetColor(G|B|I);
							}
							if(retl[hiscs]==1)
							{
								if(Gsty[i][j][hiscs]==1) SetColor();
								if(Gsty[i][j][hiscs]==2) SetColor(R|B|I);
							}
							cout<<Gses[i][hiscs][j];
						}
						cout<<endl;
					}
					SetColor();
					cout<<endl<<"down=continue";
					while(getch()!=80);
				}
				break;
			}
			case 2:
			{
				break;
			}
			case 4:
			{
				imposWords.clear();
				string chA1[32]={"View list","Search on internet","Rule Manager","Exit and reset"};
				int A1Ch=-1,page=0;
				imposWords.clear();
				int ret=3;
				map<unsigned int,string> hgs;
				map<unsigned int,int> stats[5];
				int alles=0,rl=3;
				while(A1Ch!=3)
				{
					A1Ch=GetSwitch(chA1,4,"Word List");
					if(A1Ch==-1) break;
					switch(A1Ch)
					{
						case 0:
						{
							int Maxpg=0,Mxps=0;
							map<int,int> posWords;
							posWords.clear();
							for(int i=0;i<M;i++)
							{
								if(!imposWords[i])
								{
									posWords[Maxpg]=i;
									Maxpg++;
								}
							}
							Mxps=Maxpg/20;
							if(Maxpg%20) Mxps++;
							page=0;
							ShowCursor();
							char chsh='a';
							int Itemp;
							while(chsh!=80)
							{
								Clear();
								printf("<-Left [%d] Right->\nPress down to exit\nJump to number:j.Jump to page:k.Jump to word:l.\n",page+1);
								for(int i=0;i<20;i++)
								{
									if(page*20+i==M) break;
									if(!imposWords[posWords[page*20+i]]) cout<<"["<<posWords[page*20+i]+1<<"] "<<Idm[posWords[page*20+i]]<<endl;
								}
								chsh=getch();
								if(chsh==75)
								{
									if(page!=0) page--;
									while(Volch(VK_LEFT));
								}
								if(chsh==77)
								{
									if(page<Mxps-1) page++;
									while(Volch(VK_RIGHT));
								}
								if(chsh=='j')
								{
									Clear();
									printf("Target Id:");
									scanf("%d",&Itemp);
									if(Itemp<=M&&Itemp>0)
									{
										page=(Itemp-1)/20;
									}
									else
									{
										printf("Invalid Id.\n");
										Delay(1000);
									}
								}
								if(chsh=='k')
								{
									Clear();
									printf("Target Page:");
									scanf("%d",&Itemp);
									if(Itemp<=648&&Itemp>0)
									{
										page=Itemp-1;
									}
									else
									{
										printf("Invalid Page.\n");
										Delay(1000);
									}
								}
								if(chsh=='l')
								{
									Clear();
									string Tword;
									printf("Target Word:");
									cin>>Tword;
									if(CheckString(Tword))
									{
										for(Itemp=0;Itemp<M;Itemp++)
										{
											if(Idm[Itemp]==Tword)
											{
												page=Itemp/20;
												break;
											}
										}
									}
									else
									{
										printf("Invalid Word.");
										Delay(1000);
									}
								}
							}
							while(Volch(VK_DOWN));
							ShowCursor(true);
							break;
						}
						case 1:
						{
							Clear();
							printf("Please input WordID,program can search on internet\n");
							int id=-1;
							while(!(id>0&&id<=M))
							{
								MoveCursor(0,1);
								cin>>id;
								if(!(id>0&&id<=M))
								{
									MoveCursor(0,2);
									SetColor(R|I);
									printf("Input 1-12953!");
									SetColor();
								}
							}
							MoveCursor(0,2);
							printf("                           ");
							char str[128];
							if(CurrentUser.SearchEngine)
							{
								sprintf(str,"cmd /c start https://www.baidu.com/s?wd=%s",Idm[id-1].c_str());
							}
							else
							{
								sprintf(str,"cmd /c start https://cn.bing.com/search?q=%s",Idm[id-1].c_str());
							}
							system(str);
							break;
						}
						case 2:
						{
							bool Upd=true;
							int cho=0,chid=1;
							char Ged='t';
							int _io=11;
							while(Ged!='q')
							{
								if(Upd)
								{
									Clear();
									_io=11;
									printf("r=select rl,q=exit,tab=add,enter=select\nReportLevel:");
									if(rl==3) SetColor(G|I);
									if(rl==2) SetColor(G|B|I);
									if(rl==1) SetColor(R|B|I);
									printf("%d\n\n",rl);
									SetColor(I);
									printf("A B C D E F G\nH I J K L M N\nO P Q   R S T\nU V W   X Y Z\n\n");
									SetColor();
									printf("History Guess:");
									if(!alles)
									{
										SetColor(R|G|I);
										printf("\nHistory is empty!");
										_io++;
										SetColor();
									}
									else
									{
										for(int i=1;i<=alles;i++)
										{
											if(!((i-1)%3))
											{
												printf("\n");
												_io++;
											}
											for(int j=0;j<5;j++)
											{
												int CoL=15;
												if(rl==3)
												{
													if(stats[j][i]==3) CoL=G|I;
													if(stats[j][i]==2) CoL=R|G|I;
												}
												if(rl==2)
												{
													if(stats[j][i]==3) stats[j][i]=2;
													if(stats[j][i]==2) CoL=B|G|I;
												}
												if(rl==1)
												{
													if(stats[j][i]==3) stats[j][i]=2;
													if(stats[j][i]==2) CoL=B|R|I;
												}
												if(i==chid&&cho==j) SetColor(CoL,I);
												else SetColor(CoL);
												cout<<hgs[i][j];
												SetColor();
											}
											printf(" ");
										}
									}
								}
								Ged=getch();
								if(Ged==MOVU)
								{
									if(chid>2)chid-=3;
									Upd=true;
								}
								if(Ged==MOVD)
								{
									if(alles-chid>=1) chid+=3;
									Upd=true;
								}
								if(Ged==MOVL)
								{
									if(cho==0&&chid!=1)
									{
										cho=4;
										chid--;
									}
									else if(cho)
									{
										cho--;
									}
									Upd=true;
								}
								if(Ged==115)
								{
									if(chid>1) chid--;
								}
								if(Ged==116)
								{
									if(chid<alles) chid++;
								}
								if(Ged==MOVR)
								{
									if(cho==4&&chid!=alles)
									{
										cho=0;
										chid++;
									}
									else if(cho-4)
									{
										cho++;
									}
									Upd=true;
								}
								if(Ged=='\t')
								{
									string _uui="_";
									while(!CheckString(_uui))
									{
										MoveCursor(0,_io);
										cin>>_uui;
										if(!CheckString(_uui))
										{
											MoveCursor(0,_io);
											for(int i=0;i<_uui.length();i++) printf(" ");
											SetColor(R|I);
											printf("\nPlease look rules!");
											SetColor();
										}
									}
									MoveCursor(0,_io+1);
									{
										printf("                   ");
									}
									alles++;
									hgs[alles]=_uui;
									for(int i=0;i<5;i++)
									{
										stats[i][alles]=1;
									}
									Upd=true;
								}
								if(Ged=='\r')
								{
									if(rl==3)
									{
										stats[cho][chid]=stats[cho][chid]%3+1;
									}
									else
									{
										stats[cho][chid]=stats[cho][chid]%2+1;
									}
									Upd=true;
								}
								if(Ged=='r')
								{
									Clear();
									int rlb=rl;
									string RLS[3]={"1:Number only","2:Fine","3:Detail"};
									rl=GetSwitch(RLS,3,"Cheat Mode")+1;
									if(rl==0) rl=rlb;
									Upd=true;
								}
							}
							imposWords.clear();
							for(int i=1;i<=alles;i++)
							{
								int Uo[5]={stats[0][i],stats[1][i],stats[2][i],stats[3][i],stats[4][i]};
								BasicPoswordSort(hgs[i],Uo,rl);
							}
							break;
						}
						default:
						{
							break;
						}
					}
				}
				break;
			}
			case 3:
			{
				Selct[0]="Welcome,"+user_select;
				Selct[1]="Login";
				Selct[2]="Logout";
				Selct[3]="Regist";
				Selct[4]="Exit";
				int SubSelect=0;
				while(SubSelect!=4)
				{
					Selct[0]="Welcome,"+user_select;
					SubSelect=GetSwitch(Selct,5,"User");
					if(SubSelect==-1) break;
					switch(SubSelect)
					{
						case 2:
						{
							if(user_select!="default")
							{
								Lock=true;
								fstream fs;
								fs.open((".\\Data\\"+user_select+"\\options.mpt").c_str(),ios::out);
								fs<<(CurrentUser.AutoHistory?"true":"false")<<endl;
								fs<<(CurrentUser.Password?"true":"false")<<endl;
								if(CurrentUser.Password)
								{
									fs<<CurrentUser.strPassword<<endl;
								}
								fs<<CurrentUser.Score<<endl;
								fs<<(CurrentUser.SearchEngine?"true":"false")<<endl;
								fs.close();
								CurrentUser.AutoHistory=false;
								CurrentUser.AutoHistory=false;
								CurrentUser.Score=0;
								CurrentUser.SearchEngine=true;
								CurrentUser.strPassword="PLEASEDZTBGZSCZFCDDMPL";
								user_select="default";
							}
							break;
						}
						case 1:
						{
							if(user_select!="default")
							{
								Clear();
								printf("please logout");
								Delay(1000);
								break;
							}
							Clear();
							printf("Please input username,default=cancel");
							NextUser="default";
							while(!real_users[NextUser])
							{
								MoveCursor(0,1);
								cin>>NextUser;
								if(NextUser=="default") break;
								if(!real_users[NextUser])
								{
									MoveCursor(0,2);
									SetColor(R|I);
									printf("Please input a real user!");
									SetColor(); 
								}
							}
							if(NextUser!="default")
							{
								system("del temp.mpt");
								system(("copy .\\data\\"+NextUser+"\\options.mpt temp.mpt").c_str());
								ufs.open("temp.mpt",ios::in);
								UserOptions TmpUser;
								bool Success=true;
								string QwqTemp;
								ufs>>QwqTemp;
								if(QwqTemp=="true") TmpUser.AutoHistory=true;
								else TmpUser.AutoHistory=false;
								ufs>>QwqTemp;
								if(QwqTemp=="true") TmpUser.Password=true;
								else TmpUser.Password=false;
								if(TmpUser.Password)
								{
									Success=false;
									
									ufs>>TmpUser.strPassword;
									Clear();
									printf("Please input password,default=cancel");
									string PasswordTemp="";
									bool Corp=false;
									while(!Corp)
									{
										MoveCursor(0,1);
										printf("                                      ");
										MoveCursor(0,1);
										char tmpChar='a';
										while(tmpChar!='\r')
										{
											tmpChar=getch();
											if(tmpChar!='\b')
											{
												if(tmpChar!='\r')
												{
													printf("*");
													PasswordTemp+=tmpChar;
												}
											}
											else
											{
												printf("\b \b");
												PasswordTemp=PasswordTemp.substr(0,PasswordTemp.length()-2);
											}
										}
										if(PasswordTemp=="default")
										{
											break;
										}
										if(PasswordTemp!=TmpUser.strPassword)
										{
											MoveCursor(0,2);
											SetColor(R|I);
											printf("Wrong password!\n");
											PasswordTemp="";
											SetColor();
										}
										else
										{
											Corp=true;
										}
									}
									if(Corp)
									{
										Success=true;
									}
								}
								if(Success)
								{
									ufs>>TmpUser.Score;
									ufs>>QwqTemp;
									if(QwqTemp=="true") TmpUser.SearchEngine=true;
									else TmpUser.SearchEngine=false;
									CurrentUser=TmpUser;
									user_select=NextUser;
									score=CurrentUser.Score;
								}
								ufs.close();
							}
							break;
						}
						case 3:
						{
							Clear();
							if(user_select!="default")
							{
								printf("Please logout");
								Delay(1000);
								break;
							}
							printf("Input username use a-z,default=cancel");
							NextUser="_";
							bool bSuccess=false;
							while(!bSuccess)
							{
								MoveCursor(0,1);
								printf("                     ");
								MoveCursor(0,1);
								cin>>NextUser;
								if(NextUser=="default") break;
								if(real_users[NextUser])
								{
									MoveCursor(0,2);
									SetColor(R|I);
									printf("Please input a new username!");
									SetColor();
								}
								else if(NextUser.length()==0)
								{
									MoveCursor(0,2);
									SetColor(R|I);
									printf("Please input!");
									SetColor();
								}
								else
								{
									bSuccess=true;
									for(int i=0;i<NextUser.length();i++)
									{
										if(!(NextUser[i]>='a'&&NextUser[i]<='z'))
										{
											MoveCursor(0,2);
											SetColor(R|I);
											printf("Please use a-z!");
											SetColor();
											bSuccess=false;
											break;
										}
									}
								}
							}
							if(bSuccess)
							{
								user_select=NextUser;
								fstream cmd1;
								cmd1.open("qwq.bat",ios::out);
								cmd1<<"cd data\nmd "<<user_select;
								cmd1.close();
								WinExec("qwq.bat",SW_SHOWNORMAL);
								Delay(250);
								system("del qwq.bat>nul");
								ufs.open(".\\Data\\root.mpt",ios::app);
								ufs<<NextUser<<endl;
								ufs.close();
								Clear();
								ufs.open((".\\Data\\"+NextUser+"\\options.mpt").c_str(),ios::out);
								printf("Auto write history?(Y/N):\n");
								char chg=getch();
								if(chg=='Y')
								{
									CurrentUser.AutoHistory=true;
								}
								else
								{
									CurrentUser.AutoHistory=false;
								}
								
								printf("Select search engine(A=Baidu,B=Microsoft Bing)\n");
								chg=getch();
								if(chg=='A')
								{
									CurrentUser.SearchEngine=true;
								}
								else
								{
									CurrentUser.SearchEngine=false;
								}
								ufs<<(CurrentUser.AutoHistory?"true":"false")<<endl;
								
								printf("Enable password?(Y/N)\n");
								chg=getch();
								if(chg=='Y')
								{
									CurrentUser.Password=true;
									bSuccess=false;
									Clear();
									printf("Input password,default=cancel");
									string tmpPassword="";
									char tmpChar='a';
									MoveCursor(0,1);
									while(tmpChar!='\r')
									{
										tmpChar=getch();
										if(tmpChar!='\b')
										{
											if(tmpChar!='\r')
											{
												printf("*");
												tmpPassword+=tmpChar;
											}
										}
										else
										{
											printf("\b \b");
											tmpPassword=tmpPassword.substr(0,tmpPassword.length()-2);
										}
									}
									if(tmpPassword=="default")
									{
										CurrentUser.Password=false;
									}
									else
									{
										CurrentUser.strPassword=tmpPassword;
									}
								}
								else
								{
									CurrentUser.Password=false;
								}
								ufs<<(CurrentUser.Password?"true":"false")<<endl;
								if(CurrentUser.Password)
								{
									ufs<<CurrentUser.strPassword<<endl;
								}
								CurrentUser.Score=0;
								score=0;
								ufs<<0<<endl;
								ufs<<(CurrentUser.SearchEngine?"true":"false")<<endl;
								ufs.close();
								real_users[user_select]=true;
							}
							break;
						}
						default:
						{
							break;
						}
					}
				}
				break;
			}
			case 5:
			{
				return 0;
			}
			default:
			{
				break;
			}
		}
	}
	return 0;
}
